import React from "react";
const Linked=()=>{
    return(
        <>
        
        </>
    )
}
export default Linked;