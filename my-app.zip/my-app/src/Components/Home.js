import React from "react";
const Home = () => {
    return (
        <>
            <h1>hOME</h1>
        </>
    )
}
export default Home;