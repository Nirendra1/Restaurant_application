import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Signup = () => {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setpassword] = useState("");
    const [confirm, setconfirm] = useState("");
    const navigate = useNavigate();


    async function Resto() {

        let item = { name, email, password, confirm }
        console.log(item)

        let result = await fetch("http://localhost:3000/posts", {
            method: "POST",
            body: JSON.stringify(item),
            headers: {

                "content-type": "application/json",

                "Accept": "application/json"

            }
        })
        result = await result.json()
        console.log("result", result)


        localStorage.setItem('name', name)
        localStorage.setItem(confirm, 'confirm')
        localStorage.setItem(password, 'password')

        navigate('/Login');

    }

    return (
        <>
            <div>
                <div className="signup">
                    <div>SignUp</div>
                </div>
                <div>
                    <div>
                        <label className="na1">Name:</label>
                        <input className="na2" type="text" placeholder="Enter Your Name" id="Name" onChange={(e) => setName(e.target.value)} />
                    </div>
                    <div className="email">
                        <label className="ram" >Email: </label>
                        <input className="email1" type="text" placeholder="Enter Email Id here " id="Email" onChange={(e) => setEmail(e.target.value)} />
                    </div>
                    <div className="password">
                        <label className="tom">Password:</label>
                        <input className="password1" type="text" placeholder="Enter Password here" id="Password" onChange={(e) => setpassword(e.target.value)} />
                    </div>
                    <div className="cpassword">
                        <label className="top"> Confirm Password:</label>
                        <input className="cpassword1" type="text" placeholder="Enter password here again" id="comfirm password" onChange={(e) => setconfirm(e.target.value)} />
                    </div>
                </div>
                {/* <Link to="/Login"> */}
                <button className="submit1" onClick={Resto}>Submit</button>
                {/* </Link> */}
            </div>
        </>
    )
}
export default Signup;