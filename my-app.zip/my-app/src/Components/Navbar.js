import React from "react";
import { Link } from "react-router-dom";
const Navbar = () => {
    return (
        <>
            <div className="app">
                <li className="navbar-lam">
                {/* <ul><Link className="" to="/">Signup</Link></ul> */}
                    {/* <ul><Link className="" to="/login">Login</Link></ul> */}
                    <ul><Link className="name1" to="/"> Home</Link></ul>
                    <ul ><Link className="name2" to="/list">List</Link></ul>
                    <ul><Link className="name3" to="/create">Create</Link></ul>
                    <ul><Link className="name4" to="/search">Search</Link></ul>
                    <ul><Link className="name5" to="/update">Update</Link></ul>
                </li>
            </div>

        </>
    )
}
export default Navbar;