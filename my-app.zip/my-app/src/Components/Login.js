import React, { useState } from "react";
import { Link } from "react-router-dom";
const Login = () => {

    const [email, setEmail] = useState([]);
    const [password, setpassword] = useState([]);

    async function handlesubmit() {

        let item = { email, password }
        console.log(item)

        let result = await fetch("http://localhost:3000/posts", {
            method: "POST",
            body: JSON.stringify(item),
            headers: {

                "content-type": "application/json",

                "Accept": "application/json"

            }
        })

        result = await result.json()
        console.log("result", result)

        // localStorage.setItem(result, 'result') 
        localStorage.setItem(password, 'password')
        localStorage.getItem(email, "email")

    }

    return (
        <>

            <div className="login">Login</div>
            <div className="log">
                <label className="login1">Email: </label>
                <input className="login2" type="text" placeholder="Enter Email id here" id="Email" onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="pa">
                <label className="pass1">Password: </label>
                <input className="pass2" type="text" placeholder="Enter Password here" id="Password" onChange={(e) => setpassword(e.target.value)} />
            </div>
            <div className="button1">

                <Link to="/Navbar">
                    <button className="button" onclick={handlesubmit}>Login</button>
                </Link>
            </div>
            <div className="new">
                {/* Create New Account */}
            </div>

        </>

    )
}
export default Login;